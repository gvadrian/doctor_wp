<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'doctor');

/** Имя пользователя MySQL */
define('DB_USER', 'homestead');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'secret');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost:33060');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'q|!N1(VvepIDi1;5:]>5rvf]]JDEPd`hkx:..;E,a*;3kW7ZOEX<RMyjGPH5o?UH');
define('SECURE_AUTH_KEY',  'v^vP/S`i!RvafzO!c-F{Wmy=,#E?Up2x,>4q7fI&CT;mJ{m[WH^T5vR@#hul;n0%');
define('LOGGED_IN_KEY',    'FzvhwCEb~u[1+IMRZe3B0>?0HBzx<gVzm3W6$__I.f-zEDdJ,p_pbaKy46K@4]Rm');
define('NONCE_KEY',        'mNPA<%CvruZ(A/):uavtp _$8j]c7$sVp,%r KwzJ^z4}t6x~?*Fng+Q>&wE]4n#');
define('AUTH_SALT',        '*UI^?W4Yb4VE#w*Rj yGFVHJt&.RJ5_*b4z=SPUHt;op}grmp-HT k]UA`L,TJ}E');
define('SECURE_AUTH_SALT', 'j`-Pl)h[{o=t:?EKzG#4I6sDB|+;vpeT6jCWPP_`Tfm0:@c!OR!u61lA^3]IxM<G');
define('LOGGED_IN_SALT',   'GDdTu$}y~?WfMgr@ YDhjnZHwTj|.z&6nNf`>hwF%5fcM$,H5Xv-J0f,j10/*37E');
define('NONCE_SALT',       ')[0({Ri6%C<,M4%<S9Pcns64:[,.S|&x1{UOBVffYc({vm56#S5;WM`HM!aFU,$G');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'do_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
